// An application to display RGB colours
// (NDE, 2010-06-07)

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


class ColourViewer implements Runnable {
  // Instance variables

  private JFrame frame;
  private JSlider redSlider;     // sliders are appropriate to control R,G,B
  private JSlider greenSlider;
  private JSlider blueSlider;
  private JLabel swatch;         // label will represent the 'colour swatch'


  public void run() {
    // Putting code to create and arrange components in separate
    // methods keeps the contructor fairly small and neat

    createComponents();
    createFrame();

    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setResizable(false);
    frame.setVisible(true);
  }


  private void createComponents() {
    // Each slider is configured identically, so we have a createSlider
    // method to do this rather than duplicate any code

    redSlider = createSlider();
    greenSlider = createSlider();
    blueSlider = createSlider();

    // Create a single event handling object and reuse it for all sliders
 
    ColourListener listener = new ColourListener(this);
    redSlider.addChangeListener(listener);
    greenSlider.addChangeListener(listener);
    blueSlider.addChangeListener(listener);

    swatch = new JLabel();
    swatch.setBackground(new Color(128, 128, 128));
    swatch.setOpaque(true);
  }


  private JSlider createSlider() {
    JSlider slider = new JSlider(JSlider.VERTICAL, 0, 255, 128);

    slider.setMajorTickSpacing(50);
    slider.setMinorTickSpacing(10);
    slider.setPaintTicks(true);
    slider.setLabelTable(slider.createStandardLabels(50));
    slider.setPaintLabels(true);

    return slider;
  }


  private void createFrame() {
    frame = new JFrame("ColourViewer");

    FlowLayout panelLayout = new FlowLayout();
    panelLayout.setHgap(10);
    JPanel sliderPanel = new JPanel(panelLayout);

    sliderPanel.add(new JLabel("R"));
    sliderPanel.add(redSlider);
    sliderPanel.add(new JLabel("G"));
    sliderPanel.add(greenSlider);
    sliderPanel.add(new JLabel("B"));
    sliderPanel.add(blueSlider);

    frame.setLayout(new GridLayout(1, 2));
    frame.add(sliderPanel);
    frame.add(swatch);

    frame.pack();
  }


  public void changeColour() {
    // Current values on sliders are used to create a colour
    // and set label's background to that colour

    int r = redSlider.getValue();
    int g = greenSlider.getValue();
    int b = blueSlider.getValue();

    swatch.setBackground(new Color(r, g, b));
  }


  public static void main(String[] args) {
    EventQueue.invokeLater(new ColourViewer());
  }
}


// Event handler

class ColourListener implements ChangeListener {
  // Class needs to know about the ColourViewer so that
  // it can change the displayed colour

  private ColourViewer colourViewer;

  public ColourListener(ColourViewer viewer) {
    colourViewer = viewer;
  }

  public void stateChanged(ChangeEvent event) {
    // This code executes whenever a slider is moved
    colourViewer.changeColour();
  }
}
