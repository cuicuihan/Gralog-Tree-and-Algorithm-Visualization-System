# Lecture 7

## Examples of Strategy Pattern

`Layouts.java` shows how the Swing UI framework uses Strategy to support
the use of different component layout algorithms with containers such
as `JPanel`.

To compile and run:

    javac Layouts.java
    java Layouts

## Examples of Observer Pattern

`ButtonDemo.java` demonstrate how the Observer pattern is used for event
handling in the Swing UI framework.  The demo creates a button and then
registers two different event handlers for clicks on that button.

To compile and run:

    javac ButtonDemo.java
    java ButtonDemo

`ColourViewer.java` provides another example of the use of the Observer
pattern.  In this case, the events are movements of a slider rather
than button clicks.

To compile and run:

    javac ColourViewer.java
    java ColourViewer
