import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;


/**
 * Comparison of standard layout managers.
 *
 * <p>Five buttons are laid out using different layout managers, on
 * different tabs of a tabbed pane.  To see properly how these layout
 * managers work, you need to try resizing the frame while viewing
 * each tab.</p>
 *
 * @author Nick Efford
 */
class Layouts implements Runnable {
  /**
   * Creates GUI for this demonstration.
   */
  public void run() {
    JTabbedPane tabs = new JTabbedPane();

    tabs.addTab("FlowLayout", new FlowPanel());
    tabs.addTab("GridLayout", new GridPanel());
    tabs.addTab("BorderLayout", new BorderPanel());
    tabs.addTab("BoxLayout [x axis]", new BoxPanel(BoxLayout.X_AXIS));
    tabs.addTab("BoxLayout [y axis]", new BoxPanel(BoxLayout.Y_AXIS));

    JFrame frame = new JFrame("Layouts");

    frame.add(tabs);
    frame.pack();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }

  /**
   * Application entry point.
   *
   * @param args Command-line arguments (unused)
   */
  public static void main(String[] args) {
    EventQueue.invokeLater(new Layouts());
  }
}


class FlowPanel extends JPanel {
  public FlowPanel() {
    setLayout(new FlowLayout());   // not strictly needed

    add(new JButton("One"));
    add(new JButton("Two"));
    add(new JButton("Three"));
    add(new JButton("Four"));
    add(new JButton("Five"));    
  }
}


class GridPanel extends JPanel {
  public GridPanel() {
    setLayout(new GridLayout(3, 2));   // 3 rows, 2 columns

    add(new JButton("One"));
    add(new JButton("Two"));
    add(new JButton("Three"));
    add(new JButton("Four"));
    add(new JButton("Five"));    
  }
}


class BorderPanel extends JPanel {
  public BorderPanel() {
    setLayout(new BorderLayout());

    add(new JButton("One"), BorderLayout.NORTH);
    add(new JButton("Two"), BorderLayout.EAST);
    add(new JButton("Three"), BorderLayout.SOUTH);
    add(new JButton("Four"), BorderLayout.WEST);
    add(new JButton("Five"), BorderLayout.CENTER);
  }
}


class BoxPanel extends JPanel {
  public BoxPanel(int axis) {
    BoxLayout layout = new BoxLayout(this, axis);
    setLayout(layout);

    add(new JButton("One"));
    add(new JButton("Two"));
    add(new JButton("Three"));
    add(new JButton("Four"));
    add(new JButton("Five"));    
  }
}
