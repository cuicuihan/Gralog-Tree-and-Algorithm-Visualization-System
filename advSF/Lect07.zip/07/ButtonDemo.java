import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


/**
 * Example of how Swing uses the Observer pattern to handle button clicks.
 *
 * @author Nick Efford
 */
class ButtonDemo implements Runnable {

  private JFrame frame;
  private JButton button;

  public void run() {
    // Create a frame for the application

    frame = new JFrame("ButtonDemo");

    // Create button that triggers two actions when clicked

    button = new JButton(new ImageIcon("world.png"));

    button.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent event) {
          JOptionPane.showMessageDialog(frame, "Hello World!");
        }
      }
    );

    button.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent event) {
          System.out.println("Hello World!");
        }
      }
    );

    // Add button to frame and make frame visible
 
    JPanel panel = new JPanel();
    panel.add(button);

    frame.add(panel);
    frame.setSize(290, 185);

    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }

  /**
   * Application entry point.
   *
   * @param args Command-line arguments (unused)
   */
  public static void main(String[] args) {
    EventQueue.invokeLater(new ButtonDemo());
  }
}
