package ase.rental;

public class Rental {
  private final Car car;
  private final int daysRented;

  public Rental(Car car, int daysRented) {
    this.car = car;
    this.daysRented = daysRented;
  }

  public Car getCar() {
    return car;
  }

  public int getDaysRented() {
    return daysRented;
  }

  public int getCharge() {
    int amount = 0;
    switch (getCar().getPriceCode()) {
      case Car.STANDARD:
        amount += 30 * getDaysRented();
        break;
      case Car.LUXURY:
        amount += 50 * getDaysRented();
        break;
      case Car.NEW_MODEL:
        amount += 40 * getDaysRented();
        break;
    }
    return amount;
  }
}
