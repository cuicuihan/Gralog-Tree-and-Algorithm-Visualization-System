import java.awt.EventQueue;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;


/**
 * Example of using JLabel (and JScrollPane) to implement
 * a genuinely useful image viewing application.
 *
 * <p>Demonstrates the use of the Decorator pattern, whereby a
 * Swing UI component is 'decorated' with scrollbars.</p>
 *
 * @author Nick Efford
 */
class ImageViewer implements Runnable {

  private String filename;
  private BufferedImage image;

  /**
   * Creates an ImageViewer for the given file.
   *
   * @param filename Name of image file to be displayed
   */
  public ImageViewer(String filename) {
    this.filename = filename;

    try {
      image = ImageIO.read(new File(filename));
    }
    catch (IOException error) {
      JOptionPane.showMessageDialog(null, error, "ImageViewer Error",
       JOptionPane.ERROR_MESSAGE);
      System.exit(1);
    }
  }

  /**
   * Displays GUI.
   */
  public void run() {
    JLabel view = new JLabel(new ImageIcon(image));

    JFrame frame = new JFrame(filename);
    //frame.add(view);
    frame.add(new JScrollPane(view));

    frame.setSize(400, 400);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }

  /**
   * Application entry point.
   *
   * @param args Command-line arguments; the first is
   *  assumed to be the name of an image file
   */
  public static void main(final String[] args) {
    if (args.length > 0) {
      EventQueue.invokeLater(new ImageViewer(args[0]));
    }
    else {
      System.err.println("Usage: java ImageViewer <imgfile>");
      System.exit(1);
    }
  }
}
