# Lecture 8

The code for this lecture demonstrates two ways in which the Decorator
pattern is used in the Java APIs.

## Swing UI Framework

`ImageViewer.java` loads an image from a file, renders that image on
a `JLabel` component and then wraps that component in a `JScrollPane`.
The latter decorates the wrapped component with scrollbars if the parent
container is too small to display the full page.

Compile and run with

    javac ImageViewer.java
    java ImageViewer jupiter.jpg

## Input/Output

`Undecorated.java` reads bytes from the file specified as a command line
argument, then reports the elapsed time.  It uses a `FileInputStream` without
any decoration.

`Buffer.java` is an almost identical program, the only difference being
that the `FileInputStream` is decorated with a `BufferedInputStream`.

Compile and run these programs with

    javac Undecorated.java
    java Undecorated book.txt

(and similarly for `Buffer.java`)

`GZipped.java` is almost identical to the other two programs, the only
difference being that it decorates the `FileInputStream` with a
`GZIPInputStream` and then with a `BufferedInputStream`.  You can run
this program on a compressed version of `book.txt` like so:

    java GZipped book.txt.gz
