import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;


public class Buffered {
  public static void main(String[] args) throws IOException {
    if (args.length == 0) {
      System.out.println("Usage: java Buffered <file>");
      System.exit(1);
    }

    // Create a decorated stream

    InputStream input = new BufferedInputStream(
                          new FileInputStream(args[0]));

    int numBytes = 0;
    long start = System.nanoTime();

    // Read from stream, counting each byte
  
    while (input.read() != -1) {
      ++numBytes;
    }
  
    // Compute elapsed time and write details to console
  
    long end = System.nanoTime();
    double elapsed = 1e-9*(end - start);

    System.out.printf("%s: %d bytes in %.3f sec%n",
      input.getClass().getName(), numBytes, elapsed);

    input.close();
  }
}
